def bubbleSort(a):
    for i in range(len(a) - 1):
        for j in range(len(a) - i - 1):
            if a[j] > a[j+1]:
                #check the conditions
                a[j], a[j+1] = a[j+1], a[j]
    return a

if __name__ == '__main__':
    a = [2,3,4,7,3,1,-9,-10,2,9,10,2,6,13]
    #input array
    print()
    print(bubbleSort(a))
    print()